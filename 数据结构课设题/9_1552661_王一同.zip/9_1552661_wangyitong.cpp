#include<iostream>
#include"tree.h"
using namespace std;
int main(){
	cout << "**                           ����������                           **" << endl;
	cout << "====================================================================" << endl;
	cout << "**                         1 --- ��������������                   **" << endl;
	cout << "**                         2 --- ����Ԫ��                         **" << endl;
	cout << "**                         3 --- ��ѯԪ��                         **" << endl;
	cout << "**                         4 --- �˳�����                         **" << endl;
	cout << "====================================================================" << endl;
	int order;
	Tree tree;
	cout << "Please select: ";
	cin >> order;
	while (order != 4){
		switch (order){
		case 1:
			tree.Build_Tree();
			break;
		case 2:
			tree.Insert();
			break;
		case 3:
			tree.Find();
			break;
		default:
			cout << "��������" << endl;
		}
		cout << "Please select: ";
		cin >> order;
	}
}