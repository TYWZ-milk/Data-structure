void NQueen(int iQueen);
void place(int row, int iQueen);
int find(int i, int k);
void print(int n);